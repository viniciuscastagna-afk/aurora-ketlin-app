# Aurora by Ketlin Roberto - PWA Sprint 1

## Rodar localmente
```bash
npm install
npm run dev
```

## Deploy Netlify
- Build command: `npm run build`
- Publish directory: `dist`

Senha do painel Ketlin: `1234`
